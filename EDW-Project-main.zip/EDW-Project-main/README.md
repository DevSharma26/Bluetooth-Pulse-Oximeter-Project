# EDW-Project
This project is our first ever foray into the world of practical electronics and an attempt to create a working device, Pulse Oximeter (in this case).
All the required info about the components, project specific details plus a beginner's overview is documented in the "project proposal" doc.
The various pointers and our fixes to some common problems are present in the "project documentation".
Also included are the arduino code, the eagle schematic and eagle board layout for the pcb.
This repo contains every piece of info and documentation that we deemed relevant for a third person to understand the motives behind the project and replicate it with elementary knowledge of electronics and pcb fabricating.
However, if any problem is encountered in the project try to troubleshoot using google and/or helpful friends/teachers/professors like we did 
happy bulding!!
